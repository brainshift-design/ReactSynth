import styles from './Separator.module.css';



export default function Separator()
{
    return (
        <div className={styles.separator}>&nbsp;</div>
    );
}
