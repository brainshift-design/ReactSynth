# react-synth
 A web-based synth and sequencer built with React and WebAudio.
